Cufon.replace(' nav li a', { fontFamily: 'Hattori Hanzo' , hover:true, textShadow:'1px 1px #d64708' });
Cufon.replace('h2, .link , .link1', { fontFamily: 'Hattori Hanzo' , hover:true , textShadow:'1px 1px #a6a6a6' });
Cufon.replace('h2 em', { fontFamily: 'Hattori Hanzo' , textShadow:'1px 1px #fac396' });